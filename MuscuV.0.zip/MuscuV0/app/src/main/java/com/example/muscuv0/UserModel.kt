package com.example.muscuv0

class UserModel (
    val id: String = "0",
    val username: String = "User 1",
    val email: String = "user1@mail.com" ,
    val password: String = "Password1",
)