package com.example.muscuv0

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class WorkoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.workout_page)
}
}