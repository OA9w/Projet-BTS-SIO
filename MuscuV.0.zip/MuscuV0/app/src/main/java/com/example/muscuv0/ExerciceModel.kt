package com.example.muscuv0

class ExerciceModel (
    val id: String = "benchpress",
    val name: String = "Bench Press",
    val description: String = "muscle targeted" ,
    val imageUrl: String = "",
    var added: Boolean = false,
    )
