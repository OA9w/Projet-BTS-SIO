package adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.muscuv0.R

class WorkoutAdapter : RecyclerView.Adapter<WorkoutAdapter.ViewHolder>(){

    //boite pour ranger tt les composants à controler
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val workoutImage = view.findViewById<ImageView>(R.id.image_item)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_vertical_workout, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {}

    override fun getItemCount(): Int = 5


}